// Assignment 2 for ECS 198F SQ26
// Symmetric Encryption Exercise
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define BUFSIZE 72

// simplifies error return
int err(const char* msg, int ecode) {
  perror(msg);
  return ecode;
}

int getBuffer(FILE* f, char* b) {
  size_t bytes_read = fread(b, 1, BUFSIZE, f);
  if (bytes_read == 0) return 0; // EOF reached, nothing read
  for (size_t i = bytes_read; i < BUFSIZE; i++) {
    b[i] = '\0'; // pad with null bytes
  }
  return 1;
}

// turns a 72 character block to a 64 byte chunk
// by squeezing out the leading bit per char
// (ASCII characters only utilize the last 7 bits per char)
void packBlock(char* og, char* n) {
  uint32_t acc = 0;
  int bits = 0;
  int out_idx = 0;
  for (int i = 0; i < 72; i++) {
    // Shift the accumulator left by 7 and append the new 7 bits
    acc = (acc << 7) | (og[i] & 0x7F);
    bits += 7;
    // Whenever we have accumulated 8 or more bits, extract a byte
    n[out_idx] = (char)((acc >> (bits & 7)) & 0xFF); // overwrites if needed
    out_idx += (bits >> 3); // this checks if we have 8 bits
    bits &= 7;
  }
  n[63] = '\0'; // final byte not used
}

void encrypt(uint64_t* c, uint64_t k) {
  // Every 64 bit chunk, we XOR with the key (with a wraparound 8 bit rightshift)
  for (int i = 0; i < 8; i++) {
    c[i] ^= k;
    k = (k >> 8) | (k << 56);
  }
}

// the exact opposite of packBlock
void unpackBlock(const char* n, char* og) {
  uint32_t acc = 0;
  int bits = 0;
  int out_idx = 0;

  for (int i = 0; i < 63; i++) {
    acc = (acc << 8) | (uint8_t)(n[i]);
    bits += 8;
    while (bits >= 7) {
      bits -= 7; 
      og[out_idx++] = (char)((acc >> bits) & 0x7F);
    }
  }
}

// f: file pointer for encryption
// k: 64 bit unsigned integer as key
int output(FILE* f, uint64_t k) {
  // make sure key is not corrupted
  // top 32 bits should be exactly opposite to the bottom 32 bits
  if (((uint32_t) (k >> 32)) != ~(uint32_t) k) return err("invalid key", -1);
  // Block cipher: encrypts every 72 ASCII characters as a block, 0x00 as padding
  char buffer[BUFSIZE];
  char chunk[64];
  while (getBuffer(f, buffer)) {
    packBlock(buffer, chunk);
    encrypt((uint64_t*) chunk, k); // this cast forces chunk into reading per 64 bits
    unpackBlock(chunk, buffer);
    fwrite(buffer, 1, BUFSIZE, stdout);
  }
  return 0;
}

// main: entry point to program, parses file pointer and key
int main(int argc, char** argv) {
  if (argc != 3) return err("Expect two arguments: File to encrypt and a 64 bit key in hex", -1);
  FILE* file = fopen(argv[1], "r");
  if (file == NULL) return err("Invalid file. Return code set to errno", errno);
  unsigned long long int key = strtoull(argv[2], NULL, 16); // guarantee to by 64 bits
  if (key == 0 || errno == ERANGE) return err("Key not in range (0, 2**64)", -1);
  return output(file, key); // main will close out file
}

